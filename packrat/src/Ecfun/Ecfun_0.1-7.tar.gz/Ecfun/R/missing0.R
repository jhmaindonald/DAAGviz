missing0 <- function(x){
  missing(x) || (length(x)<1)
}
